import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../contexts/LanguageContext';
import { translations } from '../translations';
import MobileNav from './navigation/MobileNav';
import Logo from './navigation/Logo';
import MainNav from './navigation/MainNav';
import NavActions from './navigation/NavActions';
import { NavItem } from './navigation/types';

const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { language } = useLanguage();
  const t = translations[language].nav;

  const mainNavItems: NavItem[] = [
    { to: "/", label: t.home },
    { to: "/services", label: t.services },
    { to: "/pricing", label: t.pricing },
    { to: "/about", label: t.about },
    { to: "/faq", label: t.faq }
  ];

  return (
    <>
      <motion.nav 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="fixed w-full bg-white/80 backdrop-blur-md z-40 py-4 px-6"
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Logo />
          <MainNav items={mainNavItems} />
          <NavActions 
            contactLabel={t.contact}
            onMenuClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            isMenuOpen={isMobileMenuOpen}
          />
        </div>
      </motion.nav>

      <MobileNav 
        isOpen={isMobileMenuOpen}
        onClose={() => setIsMobileMenuOpen(false)}
        items={[...mainNavItems, { to: "/contact", label: t.contact }]}
      />
    </>
  );
};

export default Navbar;
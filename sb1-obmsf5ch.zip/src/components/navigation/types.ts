export interface NavItem {
  to: string;
  label: string;
}

export type NavItems = NavItem[];
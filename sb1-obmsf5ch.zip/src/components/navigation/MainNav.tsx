import React from 'react';
import NavLink from './NavLink';
import { NavItems } from './types';

interface MainNavProps {
  items: NavItems;
}

const MainNav: React.FC<MainNavProps> = ({ items }) => (
  <div className="hidden lg:flex flex-1 justify-center items-center space-x-8">
    {items.map(item => (
      <NavLink key={item.to} to={item.to}>
        {item.label}
      </NavLink>
    ))}
  </div>
);

export default MainNav;
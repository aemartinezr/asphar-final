import React from 'react';
import { Menu } from 'lucide-react';
import { LanguageSwitch } from '../LanguageSwitch';
import NavLink from './NavLink';

interface NavActionsProps {
  contactLabel: string;
  onMenuClick: () => void;
  isMenuOpen: boolean;
}

const NavActions: React.FC<NavActionsProps> = ({ contactLabel, onMenuClick, isMenuOpen }) => (
  <div className="flex items-center space-x-4 flex-shrink-0">
    <LanguageSwitch />
    <NavLink 
      to="/contact"
      className="hidden sm:block bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-2 rounded-full transition-all duration-300"
    >
      {contactLabel}
    </NavLink>
    <button
      onClick={onMenuClick}
      className="p-2 hover:bg-gray-100 rounded-full lg:hidden"
      aria-label={isMenuOpen ? "Close menu" : "Open menu"}
    >
      <Menu className="w-6 h-6" />
    </button>
  </div>
);

export default NavActions;
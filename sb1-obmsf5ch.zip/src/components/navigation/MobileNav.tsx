import React from 'react';
import { X } from 'lucide-react';
import NavLink from './NavLink';
import { NavItems } from './types';

interface MobileNavProps {
  isOpen: boolean;
  onClose: () => void;
  items: NavItems;
}

const MobileNav: React.FC<MobileNavProps> = ({ isOpen, onClose, items }) => {
  return (
    <div
      className={`fixed inset-0 bg-gray-800/50 backdrop-blur-sm transition-opacity duration-300 z-50 lg:hidden ${
        isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
      }`}
      onClick={onClose}
    >
      <div
        className={`fixed right-0 top-0 h-full w-64 bg-white shadow-xl transition-transform duration-300 ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-4 flex justify-between items-center border-b">
          <span className="text-xl font-bold text-gray-900">Menu</span>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full"
            aria-label="Close menu"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        <nav className="p-4">
          <ul className="space-y-4">
            {items.map((item) => (
              <li key={item.to}>
                <NavLink
                  to={item.to}
                  className="block py-2"
                  onClick={onClose}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </div>
  );
};

export default MobileNav;
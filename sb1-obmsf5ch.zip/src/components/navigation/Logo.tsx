import React from 'react';
import { Link } from 'react-router-dom';
import { Shield } from 'lucide-react';

const Logo: React.FC = () => (
  <Link to="/" className="flex items-center space-x-2">
    <Shield className="w-6 h-6 text-transparent bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text" />
    <span className="text-xl font-bold text-transparent bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text">
      ASPHAR
    </span>
  </Link>
);

export default Logo;
import React from 'react';
import NavLink from './NavLink';
import { NavItems } from './types';

interface DesktopNavProps {
  items: NavItems;
}

const DesktopNav: React.FC<DesktopNavProps> = ({ items }) => (
  <div className="hidden lg:flex flex-grow justify-center items-center space-x-8">
    {items.map(item => (
      <NavLink key={item.to} to={item.to}>
        {item.label}
      </NavLink>
    ))}
  </div>
);

export default DesktopNav;
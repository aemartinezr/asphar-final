import React from 'react';
import { Link } from 'react-router-dom';
import { X } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { translations } from '../translations';

interface MobileNavProps {
  isOpen: boolean;
  onClose: () => void;
}

const MobileNav = ({ isOpen, onClose }: MobileNavProps) => {
  const { language } = useLanguage();
  const t = translations[language].nav;

  return (
    <div
      className={`fixed inset-0 bg-gray-800/50 backdrop-blur-sm transition-opacity duration-300 z-50 lg:hidden ${
        isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
      }`}
      onClick={onClose}
    >
      <div
        className={`fixed right-0 top-0 h-full w-64 bg-white shadow-xl transition-transform duration-300 ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-4 flex justify-between items-center border-b">
          <span className="text-xl font-bold text-gray-900">Menu</span>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full"
            aria-label="Close menu"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        <nav className="p-4">
          <ul className="space-y-4">
            {[
              { to: "/", label: t.home },
              { to: "/services", label: t.services },
              { to: "/pricing", label: t.pricing },
              { to: "/about", label: t.about },
              { to: "/faq", label: t.faq },
              { to: "/contact", label: t.contact }
            ].map((link) => (
              <li key={link.to}>
                <Link
                  to={link.to}
                  className="block py-2 text-gray-600 hover:text-blue-600 transition-colors"
                  onClick={onClose}
                >
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </div>
  );
};

export default MobileNav;
import React from 'react';
import { CheckCircle, AlertCircle } from 'lucide-react';

interface SubmissionMessageProps {
  status: 'idle' | 'success' | 'error';
}

const SubmissionMessage: React.FC<SubmissionMessageProps> = ({ status }) => {
  if (status === 'idle') return null;

  return (
    <div
      className={`flex items-center p-4 mb-6 rounded-lg ${
        status === 'success' 
          ? 'bg-green-50 text-green-700' 
          : 'bg-red-50 text-red-700'
      }`}
    >
      {status === 'success' ? (
        <>
          <CheckCircle className="w-5 h-5 mr-2" />
          <span>Thank you for your message! We will get back to you soon.</span>
        </>
      ) : (
        <>
          <AlertCircle className="w-5 h-5 mr-2" />
          <span>Oops! There was an error. Please try again.</span>
        </>
      )}
    </div>
  );
};

export default SubmissionMessage;
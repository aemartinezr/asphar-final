import { useState, FormEvent } from 'react';

interface FormData {
  name: string;
  email: string;
  service: string;
  subject: string;
  message: string;
}

interface UseFormSubmission {
  isSubmitting: boolean;
  submitStatus: 'idle' | 'success' | 'error';
  handleSubmit: (e: FormEvent<HTMLFormElement>, formData: FormData) => Promise<void>;
}

export const useFormSubmission = (): UseFormSubmission => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: FormEvent<HTMLFormElement>, formData: FormData) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('idle');

    try {
      const response = await fetch('https://formspree.io/f/mgvvyrbb', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) throw new Error('Submission failed');
      
      setSubmitStatus('success');
    } catch (error) {
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return { isSubmitting, submitStatus, handleSubmit };
};